  ######################################################

# Project: Project 3
# UIN: 656538534
# repl.it URL: https://replit.com/@MykolaTurchak/Project-3#main.py
 
######################################################

import csv
import requests
import json
import matplotlib.pyplot as plt


def get_data_from_file(fn, format=""):

  # if csv, handle csv file
  if 'csv' in fn:
    with open(fn) as f:
      
      reader = csv.reader(f)
      data = list(reader)

  # elif json, handle json file
  elif 'json' in fn:
    
    with open('states_titlecase.json') as f:
      reader = json.load(f)
      data = list(reader)

  return data




def get_data_from_internet(url, format='json'):

  # if json, handle json file
  if format == 'json':
    req = requests.get(url)
    j_req = req.json()
    return j_req

  # elif csv, handle csv file
  elif format == 'csv':
    req = requests.get(url)
    csv_req = list(req)
    return csv_req




def get_state_population(state_populations,state_name):

  #using get_data_from_internet to open data
  data = get_data_from_internet(state_populations)

  #looping through the data
  for state_pop in data:
    for state in state_pop:
      #skipping first line in the file and comparing the names
      if state[1:] == state_name:

        return int(state_pop[state])




def get_state_name(state_names,state_code):

  #using get_data_from_internet to open data
  data = get_data_from_file(state_names)

  for state_name_dict in data:
    for state_name in state_name_dict:
      #if entered state code is found in file, return the name 
      if state_code == state_name_dict[state_name]:

        return state_name_dict['name']




def get_index_for_column_label(header_row,column_label):

  #variable to keep track of index
  index = 0

  #looping through the first row of file
  for data in header_row:
    
    #if input was found returning the index
    if data == column_label:
      return index

    #else increasing the index
    else:
      index+=1



#Problems start here


#1
def national_avg_all(fn):

  #saving file starting from the second line into 'data'
  data = get_data_from_file(fn)[1:]

  #creating variables
  num_of_ret  = 0
  income = 0

  #looping through the data and adding values
  for iteam in data:
    income += int(iteam[96])
    num_of_ret += int(iteam[4])

  #dividing, rounding, and returning data in a specific format
  avg = round(income/num_of_ret*1000)

  return "${:8.0f}".format(avg)




#2
def national_avg_agi(fn):

  #saving file starting from the second line into 'data'
  data = get_data_from_file(fn)[1:]

  #creating variables 
  dct = {}

  #looping through the numbers, which will be used to compare group_agi
  for i in range(1,7):

    #reseting the variables
    num_of_ret  = 0
    income = 0

    #looping through the data and adding values IF agi is the same as 'i'
    for iteam in data:
      if int(iteam[3]) == i:

        num_of_ret += int(iteam[4])
        income += int(iteam[96])

    #dividing, rounding, and returning data in a specific format
    avg = round(income/num_of_ret*1000)
    dct[f'Group {i}']  = "${:8.0f}".format(avg)

  return dct




#3
def national_avg_state(fn,state_names, state_populations,for_graph=False):

  #saving file starting from the second line into 'data'
  data = get_data_from_file(fn)[1:]
  
  #creating variables to late store the data
  lst = []
  dct = {}

  #appending each state in data IF it is not in the list
  for iteam in data:
    if iteam[1] not in lst:
      lst.append(iteam[1])

  #looping through every state we appended
  for state in lst:

    #reseting the income
    income = 0

    #looping through the data and adding values IF state is in 'lst'
    for iteam in data:
      if iteam[1] == state:
        
        state_name = get_state_name(state_names,iteam[1])
        population = get_state_population(state_populations, state_name)
        income += int(iteam[96])

    #dividing, rounding, and returning data in a specific format
    avg = round(income/population*1000)

    #if statement is used when dealing with the graph to exclude formating
    if for_graph == False:
      dct[state]  = "${:8.0f}".format(avg)
      
    elif for_graph == True:
      dct[state]  = avg
      

  return dct



#4
def state_avg_taxable_income_all(fn,state_code):

  #saving file starting from the second line into 'data'
  data = get_data_from_file(fn)[1:]

  #creating variables to late store the data
  num_of_ret  = 0
  income = 0

  #looping through the data and adding values IF state_code entered is in 'lst'
  for iteam in data:
    if iteam[1] == state_code:
      num_of_ret += int(iteam[4])
      income += int(iteam[96])

  #dividing, rounding, and returning data in a specific format
  avg = round(income/num_of_ret*1000)

  return "${:8.0f}".format(avg)




#5
def state_avg_taxable_income_agi(fn,state_code):

  #saving file starting from the second line into 'data'
  data = get_data_from_file(fn)[1:]

  #creating variables to late store the data
  dct = {}

  #looping through the numbers, which will be used to compare group_agi
  for i in range(1,7):

    #reseting the variables
    num_of_ret  = 0
    income = 0

    #looping through the data and adding values IF state_code entered is in 'lst' and IF agi is the same as 'i'
    for iteam in data:
      if int(iteam[3]) == i and iteam[1] == state_code:
        
        num_of_ret += int(iteam[4])
        income += int(iteam[96])


    #dividing, rounding, and returning data in a specific format
    avg = round(income/num_of_ret*1000)
    dct[f'Group {i}']  = "${:8.0f}".format(avg)

  return dct




#6
def state_dependents_agi(fn,state_code):

  #saving file starting from the second line into 'data'
  data = get_data_from_file(fn)[1:]

  #creating variables to late store the data
  dct = {}

  #looping through the numbers, which will be used to compare group_agi
  for i in range(1,7):

    #reseting the variables
    num_of_ret  = 0
    NUMDEP = 0

    #looping through the data and adding values IF state_code entered is in 'lst' and IF agi is the same as 'i'    
    for iteam in data:
      if int(iteam[3]) == i and iteam[1] == state_code:

        num_of_ret += int(iteam[4])
        NUMDEP += int(iteam[13])


    #dividing, rounding, and returning data in a specific format  
    avg = round(NUMDEP/num_of_ret,2)
    dct[f'Group {i}']  = "{:8.2f}".format(avg)

  return dct




#7
def state_no_taxable_income_agi(fn,state_code):

  #saving file starting from the second line into 'data'
  data = get_data_from_file(fn)[1:]

  #creating variables to late store the data
  dct = {}

  #looping through the numbers, which will be used to compare group_agi
  for i in range(1,7):

    #reseting the variable
    num_of_ret  = 0

    #looping through the data and adding values IF state_code entered is in 'lst' and IF agi is the same as 'i'    
    for iteam in data:
      if int(iteam[3]) == i and iteam[1] == state_code:
        
        num_of_ret += int(iteam[4])
        no_income = num_of_ret - int(iteam[95])


    #dividing, rounding, and returning data in a specific format
    avg = round(no_income/num_of_ret*100,2)
    dct[f'Group {i}']  = "{:8.2f}".format(avg)

  return dct




#8
def taxable_income_per_resident(fn,state_names, state_populations,state_code):

    #saving file into 'data'
  data = national_avg_state(fn,state_names, state_populations)

  #looping through states in 'data' and returning the data if 'state' matches the input
  for state in data:
    if state == state_code:
      return data[state]
  



#9
def percentage_returns_agi(fn,state_code):

  #saving file starting from the second line into 'data'
  data = get_data_from_file(fn)[1:]

  #creating variables to late store the data
  dct = {}
  all_ret  = 0
  num_of_ret = 0

  #summing all values in data if state matches entered state_code 
  for iteam in data:
    if iteam[1] == state_code:
      all_ret += int(iteam[4])

  #looping through the numbers, which will be used to compare group_agi
  for i in range(1,7):

    #reseting the variable
    num_of_ret = 0

    #looping through the data and adding values IF state_code entered is in 'lst' and IF agi is the same as 'i' 
    for iteam in data:
      if int(iteam[3]) == i and iteam[1] == state_code:
        num_of_ret += int(iteam[4])
        
    #dividing, rounding, and returning data in a specific format    
    avg_ret = round(num_of_ret/all_ret*100,2)
    dct[f'Group {i}'] = "{:8.2f}".format(avg_ret)

  return dct




#10
def percentage_tax_income_agi(fn,state_code):
  
  #saving file starting from the second line into 'data'
  data = get_data_from_file(fn)[1:]

  #creating variables to late store the data
  dct = {}
  all_income  = 0
  income = 0

  #summing all values in data if state matches entered state_code 
  for iteam in data:
      if iteam[1] == state_code:
        all_income += int(iteam[96])

  #looping through the numbers, which will be used to compare group_agi
  for i in range(1,7):

    #reseting the variable
    income = 0

    #looping through the data and adding values IF state_code entered is in 'lst' and IF agi is the same as 'i' 
    for iteam in data:
      if int(iteam[3]) == i and iteam[1] == state_code:
        income += int(iteam[96])

    #dividing, rounding, and returning data in a specific format     
    avg_income = round(income/all_income*100,2)
    dct[f'Group {i}'] = "{:8.2f}".format(avg_income)

  return dct





#pie chart #1
def chart1(fn,state_code):

  #saving information from function into 'data'
  data = percentage_returns_agi('tax_return_data_2018.csv',state_code)

  #creating variables for chart
  labels = []
  weight =[]
  
  #looping through data and appending information into 2 lists
  for group in data:
    weight.append(data[group])
    labels.append(group)

  #ploting
  
  fig1, ax1 = plt.subplots()
  ax1.pie(weight, labels=labels, autopct='%1.1f%%',
        shadow=True, startangle=90)
  ax1.axis('equal')
  plt.title(label = "Percentage of returns for each agi_group", fontsize='12', 
          loc="center",
          fontstyle='oblique')

  # plt.show()
  plt.savefig("pie1_" + state_code + ".png")




#pie chart #2
def chart2(fn,state_code):

  #saving information from function into 'data'
  data = percentage_tax_income_agi('tax_return_data_2018.csv',state_code)

  #creating variables for chart
  labels = []
  weight =[]
  
  #looping through data and appending information into 2 lists
  for group in data:
    weight.append(data[group])
    labels.append(group)

  #ploting
  
  
  fig1, ax1 = plt.subplots()
  ax1.pie(weight, labels=labels, autopct='%1.1f%%',
        shadow=True, startangle=90)
  ax1.axis('equal') 
  plt.title(label = "Percentage of taxable income for each agi_group", fontsize='12', 
          loc="center",
          fontstyle='oblique')
  
  # plt.show()
  plt.savefig("pie2_" + state_code + ".png")




#BAR chart
def bar_chart(fn,state_names, state_populations,for_graph):

  #saving information from function into 'data'
  data = national_avg_state(fn,state_names, state_populations,for_graph)

  #creating variables to late store the data
  dct = {}

  #sorting and reversing the data into a list
  data_rev = sorted(data.items(),reverse = True, key = lambda kv: kv[1])

  #transforming list into dictionary
  for iteam in data_rev:
    dct[iteam[0]] = iteam[1]

  #creating variables for chart
  x = []
  y =[]

  #looping through 'dct' and appending information into 2 lists
  for state in dct:
    x.append(state)
    y.append(data[state])

  #getting the position
  x_pos = [i for i, _ in enumerate(x)]

  #ploting and adding titles
  plt.bar(x_pos, y, color='green')
  plt.xlabel("States")
  plt.ylabel("Average taxable income")
  plt.title("Average taxable income (per resident) per State")

  plt.xticks(x_pos, x)

  # plt.show()
  plt.savefig("bar1.png")



def main():

  # header_row = returns_data[0]
  # print (get_index_for_column_label(header_row, "N04800")) 
  # # 4


  #variables for the functions
  fn = "tax_return_data_2018.csv"
  state_names = 'states_titlecase.json'
  state_populations = 'https://raw.githubusercontent.com/heymrhayes/class_files/main/state_populations_2018.txt'
  state_code = input('Please enter state code: ')

  #letting the user know, his data is in progress
  print("\nPlease wait, loading the data...")

  #header
  def answer_header(question_number, question_labels):

    header = "\n"*2
    header += "="*60 + "\n"
    header += "Question " + str(question_number) + "\n"
    header += question_labels[question_number] + "\n"
    header += "="*60 + "\n"
    return header
  
  #list of questions
  question_labels = [
    '',
    "average taxable income per return across all groups",
    "average taxable income per return for each agi group",
    "average taxable income (per resident) per state",
    "average taxable income per return across all groups",
    "average taxable income per return for each agi group",
    "average dependents per return for each agi group",
    "percentage of returns with no taxable income per agi group",
    "average taxable income per resident",
    "percentage of returns for each agi_group",
    "percentage of taxable income for each agi_group"
  ]

  #list of functions
  questions = [
    national_avg_all(fn),
    national_avg_agi(fn),
    national_avg_state(fn,state_names, state_populations),
    state_avg_taxable_income_all(fn,state_code),
    state_avg_taxable_income_agi(fn,state_code),
    state_dependents_agi(fn,state_code),
    state_no_taxable_income_agi(fn,state_code),
    taxable_income_per_resident(fn,state_names,state_populations,state_code),
    percentage_returns_agi(fn,state_code),
    percentage_tax_income_agi(fn,state_code)
  ]


  #Writting files and creating graphs
  
  # Bar Chart #1
  bar_chart(fn,state_names, state_populations,True)
  # Chart #1
  chart1(fn,state_code)
  # Chart #2
  chart2(fn,state_code)

  #adding information to the file

  #loop for 10 questions
  for i in range(10):

    #saving list into a shorter variable for easier use
    data = questions[i]

    #checking data type and appending data to the file
    if type(data) == dict:
      f = open("answers" + state_code + ".txt" ,'a')
      f.write(str(answer_header(i+1,question_labels)))

      for info in data:
        if i == 9 or i == 8 or i==6:
          f.write('\n' + str(info + ': ' + f'{data[info]}%'))
        else:
          f.write('\n' + str(info + ': ' + data[info]))

      f.close()

    elif type(data) == list:
      f = open("answers" + state_code + ".txt" ,'a')
      f.write(str(answer_header(i+1,question_labels)))

      for info in data:
        f.write('\n' + str(info))

      f.close() 

    elif type(data) == str:

        f = open("answers" + state_code + ".txt" ,'a')
        f.write(str(answer_header(i+1,question_labels)))
        f.write( '\n' + str(data))
        f.close()   

  #letting user know that his information is ready
  print('\nFiles and graphs have been created!')

#calling the function
main()